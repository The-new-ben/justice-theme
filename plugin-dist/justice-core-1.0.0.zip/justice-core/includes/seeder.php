﻿<?php
/**
 * Justice Core ג€” Lawyer Seeder (v4)
 *
 * Two modes:
 * 1. Admin-init auto-seed: creates 10 demo lawyers once (uje_seeded_v4 flag).
 * 2. CSV seeder via REST POST /seed-lawyers ג€” reads project-control/lawyer-seed.csv.
 *
 * REST: POST /wp-json/justice-core/v1/seed-lawyers (admin only)
 *
 * @package JusticeCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ג”€ג”€ג”€ Auto-seed on admin_init (runs once) ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€

add_action( 'admin_init', 'uje_maybe_auto_seed' );

function uje_maybe_auto_seed(): void {
	if ( ! current_user_can( 'manage_options' ) || ! (bool) apply_filters( 'justice_core_enable_demo_lawyer_auto_seed', false ) ) {
		return;
	}
	if ( get_option( 'uje_seeded_v4' ) ) {
		return;
	}

	$city_map = array(
		'tel-aviv'      => '׳×׳ ׳׳‘׳™׳‘',
		'jerusalem'     => '׳™׳¨׳•׳©׳׳™׳',
		'haifa'         => '׳—׳™׳₪׳”',
		'beer-sheva'    => '׳‘׳׳¨ ׳©׳‘׳¢',
		'ramat-gan'     => '׳¨׳׳× ׳’׳',
		'herzliya'      => '׳”׳¨׳¦׳׳™׳”',
		'netanya'       => '׳ ׳×׳ ׳™׳”',
		'petah-tikva'   => '׳₪׳×׳— ׳×׳§׳•׳•׳”',
		'rishon-lezion' => '׳¨׳׳©׳•׳ ׳׳¦׳™׳•׳',
		'ashdod'        => '׳׳©׳“׳•׳“',
	);

	$lawyers = array(
		array( 'heb' => '׳¢׳•"׳“ ׳׳׳™׳” ׳¨׳•׳˜׳ ׳‘׳¨׳’',  'firm' => '׳׳©׳¨׳“ ׳¨׳•׳˜׳ ׳‘׳¨׳’ ג€” ׳“׳™׳ ׳™ ׳׳©׳₪׳—׳”',   'area' => 'family-law',     'area_heb' => '׳“׳™׳ ׳™ ׳׳©׳₪׳—׳”',  'city' => 'tel-aviv',      'phone' => '03-5551234', 'whatsapp' => '0545551234', 'years' => 18, 'priority' => 100, 'bio' => '׳׳•׳׳—׳™׳× ׳‘׳“׳™׳ ׳™ ׳׳©׳₪׳—׳”, ׳’׳™׳¨׳•׳©׳™׳ ׳•׳׳©׳׳•׳¨׳× ׳™׳׳“׳™׳. ׳׳¢׳ 18 ׳©׳ ׳•׳× ׳ ׳™׳¡׳™׳•׳.' ),
		array( 'heb' => '׳¢׳•"׳“ ׳“׳•׳“ ׳›׳”׳',        'firm' => '׳›׳”׳ ג€” ׳”׳’׳ ׳” ׳₪׳׳™׳׳™׳×',           'area' => 'criminal-law',   'area_heb' => '׳׳©׳₪׳˜ ׳₪׳׳™׳׳™',  'city' => 'jerusalem',     'phone' => '02-5559876', 'whatsapp' => '0505559876', 'years' => 22, 'priority' => 95,  'bio' => '׳¢׳•׳¨׳ ׳“׳™׳ ׳₪׳׳™׳׳™ ׳‘׳›׳™׳¨, ׳׳•׳׳—׳” ׳‘׳¢׳‘׳™׳¨׳•׳× ׳¦׳•׳•׳׳¨׳•׳ ׳׳‘׳ ׳•׳”׳•׳ ׳׳”.' ),
		array( 'heb' => '׳¢׳•"׳“ ׳©׳¨׳” ׳׳•׳™',        'firm' => '׳׳•׳™ ׳ ׳“׳"׳ ׳•׳׳§׳¨׳§׳¢׳™׳',          'area' => 'real-estate-law','area_heb' => '׳׳§׳¨׳§׳¢׳™׳',     'city' => 'haifa',         'phone' => '04-5553456', 'whatsapp' => '0525553456', 'years' => 15, 'priority' => 90,  'bio' => '׳׳×׳׳—׳” ׳‘׳¢׳¡׳§׳׳•׳× ׳ ׳“׳"׳, ׳׳™׳§׳•׳™׳™ ׳‘׳ ׳™׳™׳” ׳•׳¨׳™׳©׳•׳ ׳˜׳׳‘׳•.' ),
		array( 'heb' => '׳¢׳•"׳“ ׳™׳•׳¡׳™ ׳׳–׳¨׳—׳™',     'firm' => '׳׳–׳¨׳—׳™ ג€” ׳“׳™׳ ׳™ ׳¢׳‘׳•׳“׳”',          'area' => 'labor-law',      'area_heb' => '׳“׳™׳ ׳™ ׳¢׳‘׳•׳“׳”',  'city' => 'tel-aviv',      'phone' => '03-5557890', 'whatsapp' => '0545557890', 'years' => 12, 'priority' => 85,  'bio' => '׳׳•׳׳—׳” ׳‘׳–׳›׳•׳™׳•׳× ׳¢׳•׳‘׳“׳™׳, ׳₪׳™׳˜׳•׳¨׳™׳ ׳©׳׳ ׳›׳“׳™׳ ׳•׳₪׳ ׳¡׳™׳”.' ),
		array( 'heb' => '׳¢׳•"׳“ ׳ ׳•׳¢׳” ׳©׳₪׳™׳¨׳',     'firm' => '׳©׳₪׳™׳¨׳ ג€” ׳’׳™׳©׳•׳¨ ׳•׳׳©׳₪׳—׳”',        'area' => 'family-law',     'area_heb' => '׳“׳™׳ ׳™ ׳׳©׳₪׳—׳”',  'city' => 'ramat-gan',     'phone' => '03-5552345', 'whatsapp' => '0535552345', 'years' => 10, 'priority' => 80,  'bio' => '׳¢׳•׳¨׳›׳× ׳“׳™׳ ׳׳¢׳ ׳™׳™׳ ׳™ ׳׳©׳₪׳—׳” ׳¢׳ ׳“׳’׳© ׳¢׳ ׳’׳™׳©׳•׳¨.' ),
		array( 'heb' => '׳¢׳•"׳“ ׳׳‘׳™ ׳‘׳-׳“׳•׳“',    'firm' => '׳‘׳-׳“׳•׳“ ג€” ׳×׳¢׳‘׳•׳¨׳”',             'area' => 'traffic-law',    'area_heb' => '׳“׳™׳ ׳™ ׳×׳¢׳‘׳•׳¨׳”', 'city' => 'beer-sheva',    'phone' => '08-5556789', 'whatsapp' => '0505556789', 'years' => 8,  'priority' => 75,  'bio' => '׳׳×׳׳—׳” ׳‘׳‘׳™׳˜׳•׳ ׳“׳•׳—׳•׳× ׳×׳ ׳•׳¢׳” ׳•׳¢׳‘׳™׳¨׳•׳× ׳ ׳”׳™׳’׳”.' ),
		array( 'heb' => '׳¢׳•"׳“ ׳×׳׳¨ ׳’׳•׳׳“׳©׳˜׳™׳™׳', 'firm' => '׳’׳•׳׳“׳©׳˜׳™׳™׳ ג€” ׳¦׳•׳•׳׳•׳× ׳•׳™׳¨׳•׳©׳•׳×',  'area' => 'inheritance-law','area_heb' => '׳“׳™׳ ׳™ ׳™׳¨׳•׳©׳”',  'city' => 'herzliya',      'phone' => '09-5551122', 'whatsapp' => '0545551122', 'years' => 20, 'priority' => 88,  'bio' => '׳׳•׳׳—׳™׳× ׳‘׳¦׳•׳•׳׳•׳×, ׳™׳¨׳•׳©׳•׳× ׳•׳ ׳™׳”׳•׳ ׳¢׳™׳–׳‘׳•׳.' ),
		array( 'heb' => '׳¢׳•"׳“ ׳׳©׳” ׳₪׳¨׳¥',        'firm' => '׳₪׳¨׳¥ ג€” ׳”׳’׳ ׳” ׳₪׳׳™׳׳™׳×',           'area' => 'criminal-law',   'area_heb' => '׳׳©׳₪׳˜ ׳₪׳׳™׳׳™',  'city' => 'petah-tikva',   'phone' => '03-5553344', 'whatsapp' => '0535553344', 'years' => 25, 'priority' => 92,  'bio' => '׳¢׳•׳¨׳ ׳“׳™׳ ׳₪׳׳™׳׳™ ׳•׳×׳™׳§, ׳™׳™׳¦׳•׳’ ׳‘׳›׳ ׳”׳¢׳¨׳›׳׳•׳×.' ),
		array( 'heb' => '׳¢׳•"׳“ ׳׳™׳׳× ׳׳‘׳¨׳”׳',     'firm' => '׳׳‘׳¨׳”׳ ג€” ׳׳©׳₪׳˜ ׳׳¡׳—׳¨׳™',          'area' => 'commercial-law', 'area_heb' => '׳׳©׳₪׳˜ ׳׳¡׳—׳¨׳™', 'city' => 'netanya',       'phone' => '09-5555566', 'whatsapp' => '0545555566', 'years' => 14, 'priority' => 82,  'bio' => '׳׳×׳׳—׳” ׳‘׳“׳™׳ ׳™ ׳—׳‘׳¨׳•׳×, ׳—׳•׳–׳™׳ ׳׳¡׳—׳¨׳™׳™׳ ׳•׳׳™׳˜׳™׳’׳¦׳™׳” ׳׳–׳¨׳—׳™׳×.' ),
		array( 'heb' => '׳¢׳•"׳“ ׳׳™׳×׳ ׳›׳¥',        'firm' => '׳›׳¥ ג€” ׳ ׳–׳™׳§׳™׳ ׳•׳₪׳™׳¦׳•׳™׳™׳',        'area' => 'torts',          'area_heb' => '׳“׳™׳ ׳™ ׳ ׳–׳™׳§׳™׳', 'city' => 'rishon-lezion', 'phone' => '03-5557788', 'whatsapp' => '0535557788', 'years' => 16, 'priority' => 86,  'bio' => '׳׳•׳׳—׳” ׳‘׳×׳‘׳™׳¢׳•׳× ׳ ׳–׳™׳§׳™׳, ׳×׳׳•׳ ׳•׳× ׳¢׳‘׳•׳“׳” ׳•׳¨׳©׳׳ ׳•׳× ׳¨׳₪׳•׳׳™׳×.' ),
	);

	foreach ( $lawyers as $l ) {
		$existing = get_posts( array(
			'post_type'      => 'justice_lawyer',
			'title'          => $l['heb'],
			'posts_per_page' => 1,
			'post_status'    => 'any',
			'fields'         => 'ids',
		) );

		if ( ! empty( $existing ) ) {
			// Update missing meta on existing
			$id = $existing[0];
			if ( 100 === (int) $l['priority'] && 'advocate-maya-rotenberg' !== get_post_field( 'post_name', $id ) ) {
				wp_update_post( array(
					'ID'        => $id,
					'post_name' => 'advocate-maya-rotenberg',
				) );
			}
			if ( ! get_post_meta( $id, 'priority_score', true ) ) {
				update_post_meta( $id, 'priority_score', $l['priority'] );
				update_post_meta( $id, 'firm_name',      $l['firm'] );
				update_post_meta( $id, 'whatsapp',       $l['whatsapp'] );
			}
			continue;
		}

		$post_id = wp_insert_post( array(
			'post_type'    => 'justice_lawyer',
			'post_title'   => $l['heb'],
			'post_name'    => 100 === (int) $l['priority'] ? 'advocate-maya-rotenberg' : 'seed-lawyer-' . sanitize_title( $l['area'] ) . '-' . absint( $l['priority'] ),
			'post_content' => $l['bio'],
			'post_status'  => 'draft',
			'post_excerpt' => $l['bio'],
		) );

		if ( is_wp_error( $post_id ) || ! $post_id ) {
			continue;
		}

		// Meta
		$meta = array(
			'lawyer_full_name'    => $l['heb'],
			'firm_name'           => $l['firm'],
			'phone'               => $l['phone'],
			'whatsapp'            => $l['whatsapp'],
			'years_experience'    => $l['years'],
			'priority_score'      => $l['priority'],
			'plan_type'           => 'free',
			'subscription_status' => 'inactive',
			'source_type'         => 'seed',
			'profile_status'      => 'draft',
			'license_status'      => 'unknown',
			'verification_status' => 'unverified',
			'featured_on_front'   => '0',
			'lead_routing_enabled'=> '0',
			'source_url'          => 'SEED_DATA',
			'internal_notes'      => 'Seed profile for testing only. Not verified and not approved for public endorsement.',
		);
		foreach ( $meta as $k => $v ) {
			update_post_meta( $post_id, $k, $v );
		}

		// City taxonomy ג€” use Hebrew name
		$city_heb = $city_map[ $l['city'] ] ?? $l['city'];
		if ( ! term_exists( $l['city'], 'city' ) ) {
			wp_insert_term( $city_heb, 'city', array( 'slug' => $l['city'] ) );
		}
		wp_set_object_terms( $post_id, $l['city'], 'city' );

		// Practice area taxonomy
		if ( ! term_exists( $l['area'], 'practice-areas' ) ) {
			wp_insert_term( $l['area_heb'], 'practice-areas', array( 'slug' => $l['area'] ) );
		}
		wp_set_object_terms( $post_id, $l['area'], 'practice-areas' );
	}

	update_option( 'uje_seeded_v4', true );
	uje_log( 'seeder', 'Auto-seeded 10 lawyer profiles (v4).' );
}

// ג”€ג”€ג”€ CSV Seeder (from project-control/lawyer-seed.csv) ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€ג”€

function uje_seed_lawyer_profile( array $row ): int|WP_Error {
	$existing = get_posts( array(
		'post_type'      => 'justice_lawyer',
		'title'          => $row['name'],
		'posts_per_page' => 1,
		'post_status'    => 'any',
		'fields'         => 'ids',
	) );

	if ( ! empty( $existing ) ) {
		return $existing[0];
	}

	$post_id = wp_insert_post( array(
		'post_type'    => 'justice_lawyer',
		'post_status'  => 'draft',
		'post_title'   => sanitize_text_field( $row['name'] ),
		'post_name'    => ! empty( $row['slug'] ) ? sanitize_title( $row['slug'] ) : 'lawyer-' . time(),
		'post_excerpt' => sanitize_text_field( $row['firm_name'] ?? '' ),
	) );

	if ( is_wp_error( $post_id ) || ! $post_id ) {
		return is_wp_error( $post_id ) ? $post_id : new WP_Error( 'insert_failed', 'wp_insert_post returned 0.' );
	}

	$meta_fields = array(
		'firm_name'           => $row['firm_name']           ?? '',
		'phone'               => $row['phone']               ?? '',
		'email'               => $row['email']               ?? '',
		'website'             => $row['website']             ?? '',
		'source_url'          => $row['source_url']          ?? '',
		'profile_status'      => $row['profile_status']      ?? 'draft',
		'verification_status' => $row['verification_status'] ?? 'unverified',
		'internal_notes'      => $row['notes']               ?? 'Seed profile.',
		'plan_type'           => 'free',
		'subscription_status' => 'inactive',
		'lead_routing_enabled'=> '0',
		'source_type'         => 'seed',
		'license_status'      => 'unknown',
	);

	foreach ( $meta_fields as $key => $value ) {
		if ( '' !== $value ) {
			update_post_meta( $post_id, $key, sanitize_text_field( $value ) );
		}
	}

	if ( ! empty( $row['city'] ) ) {
		wp_set_object_terms( $post_id, trim( $row['city'] ), 'city', false );
	}

	if ( ! empty( $row['practice_areas'] ) ) {
		$areas = array_map( 'trim', explode( ',', $row['practice_areas'] ) );
		wp_set_object_terms( $post_id, $areas, 'practice-areas', false );
	}

	return $post_id;
}

function uje_run_seed(): array {
	$csv_path = UJE_DIR . '../project-control/lawyer-seed.csv';
	if ( ! file_exists( $csv_path ) ) {
		$csv_path = UJE_DIR . 'data/lawyer-seed.csv';
	}
	if ( ! file_exists( $csv_path ) ) {
		return array( 'error' => 'CSV file not found: ' . $csv_path );
	}

	$handle = fopen( $csv_path, 'r' );
	if ( ! $handle ) {
		return array( 'error' => 'Cannot open CSV file.' );
	}

	$headers = fgetcsv( $handle );
	$results = array( 'created' => 0, 'skipped' => 0, 'errors' => 0 );

	while ( ( $data = fgetcsv( $handle ) ) !== false ) {
		if ( count( $data ) !== count( $headers ) ) {
			$results['errors']++;
			continue;
		}
		$row    = array_combine( $headers, $data );
		$result = uje_seed_lawyer_profile( $row );

		if ( is_wp_error( $result ) ) {
			$results['errors']++;
		} elseif ( 'draft' === get_post_status( $result ) ) {
			$results['created']++;
		} else {
			$results['skipped']++;
		}
	}

	fclose( $handle );
	uje_log( 'seeder_csv', 'CSV seed completed.', $results );
	return $results;
}

// REST endpoint for manual seeding
add_action( 'rest_api_init', function () {
	register_rest_route( 'justice-core/v1', '/seed-lawyers', array(
		'methods'             => 'POST',
		'callback'            => function () {
			return new WP_REST_Response( uje_run_seed(), 200 );
		},
		'permission_callback' => function () {
			return current_user_can( 'manage_options' ) && (bool) apply_filters( 'justice_core_enable_demo_lawyer_rest_seed', false );
		},
	) );

	// Reset seed flag (forces re-seed)
	register_rest_route( 'justice-core/v1', '/seed-reset', array(
		'methods'             => 'POST',
		'callback'            => function () {
			delete_option( 'uje_seeded_v4' );
			uje_log( 'seeder_reset', 'Seed flag cleared. Will re-seed on next admin_init.' );
			return new WP_REST_Response( array( 'ok' => true, 'message' => 'Seed flag cleared.' ), 200 );
		},
		'permission_callback' => function () {
			return current_user_can( 'manage_options' ) && (bool) apply_filters( 'justice_core_enable_demo_lawyer_seed_reset', false );
		},
	) );
} );
