<?php
/**
 * Practice-area page polish + sitewide WhatsApp lead button.
 *
 * Owner QA 2026-07-07: practice-area hubs rendered giant blank walls
 * because full multi-thousand-word guides live in the TERM DESCRIPTIONS
 * and the theme prints them inside the narrow hero column; the archive
 * query also rendered hundreds of article cards in one ~1MB page.
 *
 * Fixes, all render-layer and instant (no theme pull needed):
 * 1. Taxonomy main query capped at 24 cards per page (pagination already
 *    renders in the template).
 * 2. The hero shows only the intro of the term description; the FULL text
 *    moves into a readable full-width section further down the same page.
 *    Zero content loss, zero URL change.
 * 3. Sitewide floating WhatsApp button (big labeled bar on mobile) whose
 *    prefilled message carries the page title and URL, so the owner knows
 *    exactly which page and intent the visitor came from.
 *
 * @package JusticeOps
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ---------------------------------------------------------------------------
// 1. Archive size cap
// ---------------------------------------------------------------------------

add_action( 'pre_get_posts', function ( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}

	if ( $query->is_tax( 'practice-areas' ) ) {
		$query->set( 'posts_per_page', 24 );
	}
}, 20 );

// ---------------------------------------------------------------------------
// 2. Hero description trim + full-width guide section
// ---------------------------------------------------------------------------

add_action( 'template_redirect', function () {
	if ( ! is_tax( 'practice-areas' ) ) {
		return;
	}

	ob_start( function ( $html ) {
		if ( false === strpos( $html, 'practice-hub-hero__description' ) ) {
			return $html;
		}

		if ( ! preg_match( '/(<div class="practice-hub-hero__description">)(.*?)(<\/div>\s*<div class="practice-hub-hero__actions)/su', $html, $m ) ) {
			return $html;
		}

		$full = $m[2];

		if ( mb_strlen( wp_strip_all_tags( $full ) ) < 900 ) {
			return $html;
		}

		// Intro: the first two paragraphs, the rest becomes its own section.
		$parts = preg_split( '/(<\/p>)/iu', $full, -1, PREG_SPLIT_DELIM_CAPTURE );
		$intro = '';
		$count = 0;

		for ( $i = 0; $i < count( $parts ) - 1; $i += 2 ) {
			$intro .= $parts[ $i ] . ( $parts[ $i + 1 ] ?? '' );
			$count++;
			if ( $count >= 2 || mb_strlen( wp_strip_all_tags( $intro ) ) > 550 ) {
				break;
			}
		}

		if ( '' === trim( wp_strip_all_tags( $intro ) ) ) {
			$intro = '<p>' . mb_substr( trim( wp_strip_all_tags( $full ) ), 0, 480 ) . '</p>';
		}

		$html = str_replace( $m[1] . $m[2], $m[1] . $intro . '<p><a class="practice-hub-more" href="#practice-full-guide">להמשך המדריך המלא בתחום</a></p>', $html );

		$section = '<section class="section practice-hub-fulldesc" id="practice-full-guide" style="background:#fff">'
			. '<div class="container"><div style="max-width:820px;margin:0 auto">'
			. '<p class="section-header__eyebrow">המדריך המלא</p>'
			. '<h2 style="margin-bottom:18px">כל מה שחשוב לדעת בתחום</h2>'
			. '<div style="line-height:1.85;text-align:justify;font-size:1.02em">' . $full . '</div>'
			. '</div></div></section>';

		// Inject the full guide right before the guides grid section.
		$anchor = '<section class="practice-hub-content section"';
		$pos    = strpos( $html, $anchor );

		if ( false !== $pos ) {
			$html = substr_replace( $html, $section, $pos, 0 );
		} else {
			$html = str_replace( '</main>', $section . '</main>', $html );
		}

		return $html;
	} );
} );

// ---------------------------------------------------------------------------
// 3. Sitewide WhatsApp lead button with page context
// ---------------------------------------------------------------------------

function justice_ops_whatsapp_href(): string {
	global $post;

	$title = '';

	if ( is_singular() && $post instanceof WP_Post ) {
		$title = get_the_title( $post );
	} elseif ( is_tax() || is_category() || is_tag() ) {
		$title = single_term_title( '', false );
	} elseif ( is_front_page() ) {
		$title = 'דף הבית';
	} elseif ( is_post_type_archive() ) {
		$title = (string) post_type_archive_title( '', false );
	}

	$url = ( is_ssl() ? 'https://' : 'http://' ) . ( $_SERVER['HTTP_HOST'] ?? 'jus-tice.co.il' ) . strtok( (string) ( $_SERVER['REQUEST_URI'] ?? '/' ), '?' );

	// On a lawyer profile the lead is about THAT professional: name them.
	if ( is_singular( 'justice_lawyer' ) ) {
		$name    = mb_substr( wp_strip_all_tags( (string) $title ), 0, 60 );
		$message = 'שלום, אני פונה מהפרופיל של ' . $name
			. ' | ' . $url
			. ' | אשמח לשוחח עם ' . $name . '.';
	} else {
		$message = 'שלום, אני פונה מהעמוד: ' . mb_substr( wp_strip_all_tags( (string) $title ), 0, 80 )
			. ' | ' . $url
			. ' | ' . 'אשמח לשוחח עם עורך דין בנושא.';
	}

	if ( function_exists( 'justice_theme_public_whatsapp_url' ) ) {
		return justice_theme_public_whatsapp_url( $message );
	}

	return 'https://wa.me/972525101555?text=' . rawurlencode( $message );
}

// RETIRED 2026-07-16 (owner order): ONE WhatsApp control sitewide. The ops
// float pill duplicated the WPCode strip (snippet 12035, the broad bar with
// the site logo + WhatsApp logo + page-title/URL prefilled message) in the
// same corner - two identical CTAs stacked. The strip is the keeper; this
// footer render is gone. justice_ops_whatsapp_href() stays for other
// surfaces that compose contextual WhatsApp links.

// ---------------------------------------------------------------------------
// 4. Lawyer profile mini-site polish
// ---------------------------------------------------------------------------

/**
 * The card-facing portrait for a lawyer: the card_photo_id override when the
 * profile carries one, otherwise its featured image. Returns attachment id.
 */
function justice_ops_lawyer_portrait_id( int $lawyer_id ): int {
	$attachment = (int) get_post_meta( $lawyer_id, 'card_photo_id', true );

	if ( ! $attachment ) {
		$attachment = (int) get_post_thumbnail_id( $lawyer_id );
	}

	return $attachment;
}

/**
 * Profile hero: when a dedicated portrait exists, the hero photo panel shows
 * it instead of the wide featured banner. Scoped to the queried profile only
 * so listing cards elsewhere on the page keep their own images.
 */
add_filter( 'post_thumbnail_html', function ( $html, $post_id, $thumbnail_id, $size, $attr ) {
	if ( ! is_singular( 'justice_lawyer' ) || (int) $post_id !== (int) get_queried_object_id() ) {
		return $html;
	}

	$portrait = (int) get_post_meta( $post_id, 'card_photo_id', true );

	if ( ! $portrait || $portrait === (int) $thumbnail_id ) {
		return $html;
	}

	$src = wp_get_attachment_image_src( $portrait, 'medium_large' );

	if ( ! $src ) {
		$src = wp_get_attachment_image_src( $portrait, 'full' );
	}

	if ( ! $src ) {
		return $html;
	}

	$alt = (string) get_post_meta( $portrait, '_wp_attachment_image_alt', true );

	if ( '' === $alt ) {
		$alt = get_the_title( $post_id );
	}

	return '<img src="' . esc_url( $src[0] ) . '" alt="' . esc_attr( $alt ) . '" width="' . (int) $src[1] . '" height="' . (int) $src[2] . '"'
		. ' loading="eager" decoding="async" itemprop="image"'
		. ' style="width:100%;height:auto;max-height:440px;object-fit:cover;object-position:center 22%;border-radius:20px;display:block" />';
}, 10, 5 );

/**
 * Social sharing image for lawyer profiles: the portrait, not the site logo.
 * A WhatsApp or Facebook share of a paid mini-site must show the person.
 */
function justice_ops_lawyer_social_image( $image ) {
	if ( ! is_singular( 'justice_lawyer' ) ) {
		return $image;
	}

	$attachment = justice_ops_lawyer_portrait_id( (int) get_queried_object_id() );

	if ( ! $attachment ) {
		return $image;
	}

	$src = wp_get_attachment_image_src( $attachment, 'large' );

	if ( ! $src ) {
		$src = wp_get_attachment_image_src( $attachment, 'full' );
	}

	return $src ? $src[0] : $image;
}
add_filter( 'wpseo_opengraph_image', 'justice_ops_lawyer_social_image' );
add_filter( 'wpseo_twitter_image', 'justice_ops_lawyer_social_image' );

// ---------------------------------------------------------------------------
// 5. Legacy URL repairs
// ---------------------------------------------------------------------------

/**
 * /contact-us/ 404s while the real page lives at /contact/. Raw path match
 * at init: the theme routing guard rewrites 404 query state before
 * template_redirect, so the fix cannot depend on is_404().
 */
add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}

	$path = strtolower( trim( (string) wp_parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ), '/' ) );

	if ( 'contact-us' === $path ) {
		wp_safe_redirect( home_url( '/contact/' ), 301 );
		exit;
	}
} );

/**
 * Bridge until the next theme pull: the repo's practice-landing template
 * renders the page's own post_content inside the pillar body
 * (practice-landing__pillar-content); the live theme predates that slot, so
 * practice landing pages with a written body rendered none of it. Inject the
 * body as the last child of the content column. Self-retires the moment the
 * theme output carries the slot natively.
 *
 * Priority -1000000: the theme's controlled practice routes render and exit
 * at -999999, so the buffer must open before them; ob_start callbacks still
 * run on exit.
 */
add_action( 'template_redirect', function () {
	if ( is_admin() || ! function_exists( 'justice_theme_get_practice_landing_config' ) ) {
		return;
	}

	// Key off the URL path, not query state: on controlled practice routes
	// the main query is force-retyped and the global post is not the page.
	$slug = strtolower( trim( (string) wp_parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ), '/' ) );

	if ( '' === $slug || false !== strpos( $slug, '/' ) ) {
		return;
	}

	if ( null === justice_theme_get_practice_landing_config( $slug ) ) {
		return;
	}

	$page = get_page_by_path( $slug, OBJECT, 'page' );

	if ( ! $page instanceof WP_Post || 'publish' !== $page->post_status ) {
		return;
	}

	if ( '' === trim( wp_strip_all_tags( (string) $page->post_content ) ) ) {
		return;
	}

	$body = apply_filters( 'the_content', $page->post_content );

	ob_start( function ( $html ) use ( $body ) {
		if ( false !== strpos( $html, 'practice-landing__pillar-content' ) ) {
			return $html;
		}

		if ( false === strpos( $html, 'legal-pillar-content' ) ) {
			return $html;
		}

		$replaced = preg_replace(
			'/(<\/div>\s*<aside class="legal-pillar-sidebar)/u',
			'<div class="practice-landing__pillar-content">' . $body . '</div>$1',
			$html,
			1
		);

		return is_string( $replaced ) ? $replaced : $html;
	} );
}, -1000000 );

/**
 * Lead timing guard fix: the theme guard rejects submissions whose
 * justice_lead_started_at is older than a day, but that timestamp is baked
 * into edge-cached pages, so any page cached longer than a day silently
 * blocks every lead it produces (parked tabs too). Bots submit fast, not
 * slow: keep the 3 second floor, drop the stale upper bound. Runs at init
 * (after the theme registered its guard) and swaps in the corrected check.
 */
add_action( 'init', function () {
	if ( ! function_exists( 'justice_theme_guard_lead_submission_spam' ) ) {
		return;
	}

	foreach ( array( 'admin_post_justice_submit_lead', 'admin_post_nopriv_justice_submit_lead' ) as $hook ) {
		remove_action( $hook, 'justice_theme_guard_lead_submission_spam', 0 );
		add_action( $hook, 'justice_ops_guard_lead_submission_spam', 0 );
	}
}, 20 );

function justice_ops_guard_lead_submission_spam(): void {
	$honeypot = isset( $_POST['justice_lead_company'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['justice_lead_company'] ) ) ) : '';

	if ( '' !== $honeypot && function_exists( 'justice_theme_redirect_blocked_lead_submission' ) ) {
		justice_theme_redirect_blocked_lead_submission( 'honeypot' );
	}

	$started_at = isset( $_POST['justice_lead_started_at'] ) ? absint( $_POST['justice_lead_started_at'] ) : 0;

	if ( 0 === $started_at ) {
		return;
	}

	$age = time() - $started_at;

	if ( $age >= 0 && $age < 3 && function_exists( 'justice_theme_redirect_blocked_lead_submission' ) ) {
		justice_theme_redirect_blocked_lead_submission( 'timing' );
	}
}
